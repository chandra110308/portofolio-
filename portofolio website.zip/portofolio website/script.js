// Init AOS
AOS.init({
  duration: 1000,
  once: true
});

// Typed.js
var typed = new Typed('#typed', {
  strings: ["Cyber Security", "Network Engineer", "IT Support"],
  typeSpeed: 70,
  backSpeed: 50,
  loop: true
});